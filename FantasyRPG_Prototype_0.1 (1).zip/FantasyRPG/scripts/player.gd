extends CharacterBody2D
class_name Player
## Top-down player: movement, HP/MP, attributes, target lock, skill casting.

signal hp_changed(current: int, maximum: int)
signal mp_changed(current: float, maximum: int)
signal died

const FIREBALL_SCENE := preload("res://scenes/fireball.tscn")

## Attributes are plain data for now. The get_* hooks below are where
## STR / INT / VIT / AGI will modify stats later.
var attributes: Dictionary = GameConfig.PLAYER_BASE_ATTRIBUTES.duplicate()

var hp: int
var mp: float
var current_target: Node2D = null

var _enemies_in_range: Array = []
var _cast_cooldown := 0.0
var _attack_playing := false
var _dead := false

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var sensor: Area2D = $TargetSensor
@onready var camera: Camera2D = $Camera2D

# ---- Stat hooks (future attribute formulas go here) ----
func get_max_hp() -> int:
    return GameConfig.PLAYER_MAX_HP  # later: + VIT bonus

func get_max_mp() -> int:
    return GameConfig.PLAYER_MAX_MP  # later: + INT bonus

func get_move_speed() -> float:
    return GameConfig.PLAYER_SPEED  # later: + AGI bonus

func get_spell_power_multiplier() -> float:
    return 1.0  # later: INT

func get_physical_damage_multiplier() -> float:
    return 1.0  # later: STR

func _ready() -> void:
    hp = get_max_hp()
    mp = float(get_max_mp())
    sprite.sprite_frames = AnimBuilder.build("player")
    sprite.play("idle")
    sprite.animation_finished.connect(_on_animation_finished)
    var shape := sensor.get_node("CollisionShape2D") as CollisionShape2D
    var circle := CircleShape2D.new()
    circle.radius = GameConfig.TARGET_LOCK_RADIUS
    shape.shape = circle
    sensor.body_entered.connect(_on_sensor_body_entered)
    sensor.body_exited.connect(_on_sensor_body_exited)

## Called by the UI after binding so bars show initial values.
func emit_stats() -> void:
    hp_changed.emit(hp, get_max_hp())
    mp_changed.emit(mp, get_max_mp())

func set_camera_limits(rect: Rect2) -> void:
    camera.limit_left = int(rect.position.x)
    camera.limit_top = int(rect.position.y)
    camera.limit_right = int(rect.end.x)
    camera.limit_bottom = int(rect.end.y)

func is_alive() -> bool:
    return not _dead

func _physics_process(delta: float) -> void:
    if _dead:
        return
    _regen_mp(delta)
    _cast_cooldown = maxf(0.0, _cast_cooldown - delta)
    var dir := _read_move_input()
    velocity = dir * get_move_speed()
    move_and_slide()
    _update_animation(dir)
    _update_target()
    if Input.is_action_just_pressed("cast_fire"):
        cast_skill("fire_magic")

func _read_move_input() -> Vector2:
    var kb := Input.get_vector("move_left", "move_right", "move_up", "move_down")
    if kb.length() > 0.01:
        return kb
    return GameManager.move_input

func _regen_mp(delta: float) -> void:
    var max_mp := get_max_mp()
    if mp < max_mp:
        mp = minf(mp + GameConfig.PLAYER_MP_REGEN_PER_SEC * delta, float(max_mp))
        mp_changed.emit(mp, max_mp)

func _update_animation(dir: Vector2) -> void:
    if dir.x != 0.0:
        sprite.flip_h = dir.x < 0.0
    if _attack_playing:
        return
    var wanted := "walk" if dir.length() > 0.1 else "idle"
    if sprite.animation != wanted:
        sprite.play(wanted)

func _on_animation_finished() -> void:
    if sprite.animation == "attack":
        _attack_playing = false

# ---------------- Target lock ----------------
func _on_sensor_body_entered(body: Node) -> void:
    if body.is_in_group("enemies") and not _enemies_in_range.has(body):
        _enemies_in_range.append(body)

func _on_sensor_body_exited(body: Node) -> void:
    _enemies_in_range.erase(body)

## Picks the nearest living enemy in range (works for many enemies later).
func _update_target() -> void:
    var best: Node2D = null
    var best_d := INF
    for e in _enemies_in_range.duplicate():
        if not is_instance_valid(e) or not e.is_alive():
            _enemies_in_range.erase(e)
            continue
        var d := global_position.distance_squared_to(e.global_position)
        if d < best_d:
            best_d = d
            best = e
    if best != current_target:
        if is_instance_valid(current_target):
            current_target.set_targeted(false)
        current_target = best
        if is_instance_valid(current_target):
            current_target.set_targeted(true)

func _has_valid_target() -> bool:
    return is_instance_valid(current_target) and current_target.is_alive()

# ---------------- Skills ----------------
## Generic projectile skill caster. Returns true if the skill was cast.
func cast_skill(skill_id: String) -> bool:
    if _dead or _cast_cooldown > 0.0:
        return false
    if not SkillManager.is_unlocked(skill_id):
        return false
    var skill := SkillManager.get_skill(skill_id)
    var cost: int = skill["mana_cost"]
    if mp < cost:
        GameManager.post_message("مانای کافی ندارید")
        return false
    if not _has_valid_target():
        GameManager.post_message("هدفی در دسترس نیست")
        return false
    mp -= cost
    mp_changed.emit(mp, get_max_mp())
    _cast_cooldown = GameConfig.CAST_COOLDOWN
    var fb := FIREBALL_SCENE.instantiate() as Fireball
    get_parent().add_child(fb)
    fb.global_position = global_position
    fb.setup(current_target, int(round(skill["damage"] * get_spell_power_multiplier())), GameConfig.FIREBALL_SPEED)
    sprite.flip_h = current_target.global_position.x < global_position.x
    _attack_playing = true
    sprite.play("attack")
    get_tree().create_timer(0.6).timeout.connect(func(): _attack_playing = false)
    return true

# ---------------- Damage ----------------
func take_damage(amount: int) -> void:
    if _dead:
        return
    hp = maxi(0, hp - amount)
    hp_changed.emit(hp, get_max_hp())
    sprite.modulate = Color(1.0, 0.45, 0.45)
    create_tween().tween_property(sprite, "modulate", Color.WHITE, 0.2)
    if hp <= 0:
        _die()

func _die() -> void:
    _dead = true
    velocity = Vector2.ZERO
    set_collision_layer(0)
    died.emit()
    GameManager.post_message("شما شکست خوردید...")
    GameManager.player_died.emit()
