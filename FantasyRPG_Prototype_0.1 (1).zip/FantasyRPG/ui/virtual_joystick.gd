extends Control
class_name VirtualJoystick
## Floating-free (fixed) touch joystick. Uses raw touch events with an index,
## so it works together with other fingers pressing buttons (multi-touch).

signal vector_changed(value: Vector2)

@export var radius := 80.0
@export var dead_zone := 0.15

var value := Vector2.ZERO
var _touch_index := -1
var _knob := Vector2.ZERO

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        var local := make_input_local(event).position
        if event.pressed and _touch_index == -1 and Rect2(Vector2.ZERO, size).has_point(local):
            _touch_index = event.index
            _update(local)
        elif not event.pressed and event.index == _touch_index:
            _release()
    elif event is InputEventScreenDrag and event.index == _touch_index:
        _update(make_input_local(event).position)

func _update(local_pos: Vector2) -> void:
    _knob = (local_pos - size / 2.0).limit_length(radius)
    var v := _knob / radius
    value = Vector2.ZERO if v.length() < dead_zone else v
    vector_changed.emit(value)
    queue_redraw()

func _release() -> void:
    _touch_index = -1
    _knob = Vector2.ZERO
    value = Vector2.ZERO
    vector_changed.emit(value)
    queue_redraw()

func _draw() -> void:
    var c := size / 2.0
    draw_circle(c, radius, Color(1, 1, 1, 0.14))
    draw_arc(c, radius, 0.0, TAU, 48, Color(1, 1, 1, 0.5), 3.0)
    draw_circle(c + _knob, radius * 0.4, Color(1, 1, 1, 0.55))
