extends RefCounted
class_name Assets
## Safe texture loading. A missing file never crashes the game:
## a coloured placeholder texture is generated instead.

static func texture(path: String, fallback_size := Vector2i(32, 32), fallback_color := Color.MAGENTA, frame_w := 32) -> Texture2D:
    if ResourceLoader.exists(path):
        var res = load(path)
        if res is Texture2D:
            return res
    push_warning("Missing asset, using placeholder: " + path)
    return placeholder(fallback_size, fallback_color, frame_w)

static func placeholder(size: Vector2i, color: Color, frame_w: int) -> Texture2D:
    var img := Image.create(size.x, size.y, false, Image.FORMAT_RGBA8)
    img.fill(Color(0, 0, 0, 0))
    var count := maxi(1, size.x / maxi(1, frame_w))
    for i in count:
        var c := color.lightened(0.12 * (i % 2))
        img.fill_rect(Rect2i(i * frame_w + 4, 4, maxi(1, frame_w - 8), maxi(1, size.y - 8)), c)
    return ImageTexture.create_from_image(img)
