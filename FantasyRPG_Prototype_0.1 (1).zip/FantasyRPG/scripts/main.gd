extends Node2D
## Level root: builds ground + walls, wires player <-> UI.

@onready var player: Player = $Player
@onready var ui: GameUI = $GameUI
@onready var ground: Sprite2D = $Ground

func _ready() -> void:
    _setup_ground()
    _build_walls()
    player.set_camera_limits(Rect2(Vector2.ZERO, GameConfig.MAP_SIZE))
    ui.bind_player(player)
    ui.cast_requested.connect(player.cast_skill)
    GameManager.player_died.connect(_on_player_died)

func _setup_ground() -> void:
    ground.texture = Assets.texture(GameConfig.TEX_GRASS, Vector2i(32, 32), Color(0.3, 0.6, 0.3), 32)
    ground.texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
    ground.centered = false
    ground.region_enabled = true
    ground.region_rect = Rect2(Vector2.ZERO, GameConfig.MAP_SIZE)

## Invisible walls around the map (World layer).
func _build_walls() -> void:
    var s := GameConfig.MAP_SIZE
    var t := 32.0
    _add_wall(Rect2(-t, -t, s.x + 2 * t, t))
    _add_wall(Rect2(-t, s.y, s.x + 2 * t, t))
    _add_wall(Rect2(-t, 0, t, s.y))
    _add_wall(Rect2(s.x, 0, t, s.y))

func _add_wall(rect: Rect2) -> void:
    var body := StaticBody2D.new()
    body.collision_layer = GameConfig.LAYER_WORLD
    body.collision_mask = 0
    var shape := CollisionShape2D.new()
    var r := RectangleShape2D.new()
    r.size = rect.size
    shape.shape = r
    body.position = rect.position + rect.size / 2.0
    body.add_child(shape)
    add_child(body)

func _on_player_died() -> void:
    await get_tree().create_timer(2.5).timeout
    UnderstandingManager.reset()
    SkillManager.reset()
    GameManager.reset_state()
    get_tree().reload_current_scene()
