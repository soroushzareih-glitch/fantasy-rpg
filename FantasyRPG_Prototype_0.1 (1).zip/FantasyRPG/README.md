# Fantasy RPG Prototype 0.1 (Godot 4.x)
Run: open the folder in Godot 4.2+ -> press F5.
Desktop test keys: WASD/arrows = move, E = interact, Space = fire.
All tunable values: scripts/game_config.gd
Replace art: drop PNG sprite sheets (horizontal strips) over the files in assets/ (same names).
Frame count is auto-detected from sheet width / frame width (see ANIMATIONS in game_config.gd).
Optional Persian font: put assets/ui/fonts/main_font.ttf (e.g. Vazirmatn) - loaded automatically.
