extends Node
## AUTOLOAD. Why: a tiny shared hub needed by many unrelated nodes
## (UI, player, book): message bus, current interactable, touch move input.

signal message_posted(text: String)
signal interactable_changed(target: Node)
signal player_died

## Written by the virtual joystick, read by the player.
var move_input := Vector2.ZERO
var current_interactable: Node = null

func _ready() -> void:
    _register_inputs()

func post_message(text: String) -> void:
    message_posted.emit(text)

func set_interactable(target: Node) -> void:
    current_interactable = target
    interactable_changed.emit(target)

func clear_interactable(target: Node) -> void:
    if current_interactable == target:
        current_interactable = null
        interactable_changed.emit(null)

func reset_state() -> void:
    current_interactable = null
    move_input = Vector2.ZERO

func interact() -> void:
    if is_instance_valid(current_interactable) and current_interactable.has_method("interact"):
        current_interactable.interact()

func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("interact"):
        interact()

## Keyboard actions for desktop testing (touch UI is the real control scheme).
func _register_inputs() -> void:
    _add_action("move_left", [KEY_A, KEY_LEFT])
    _add_action("move_right", [KEY_D, KEY_RIGHT])
    _add_action("move_up", [KEY_W, KEY_UP])
    _add_action("move_down", [KEY_S, KEY_DOWN])
    _add_action("interact", [KEY_E])
    _add_action("cast_fire", [KEY_SPACE])

func _add_action(action: String, keys: Array) -> void:
    if not InputMap.has_action(action):
        InputMap.add_action(action)
    for k in keys:
        var ev := InputEventKey.new()
        ev.physical_keycode = k
        InputMap.action_add_event(action, ev)
