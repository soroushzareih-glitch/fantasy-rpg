extends RefCounted
class_name AnimBuilder
## Builds a SpriteFrames resource from GameConfig.ANIMATIONS.
## To use AI-generated art: replace the PNG strips in assets/ (same file names).
## Frame count = sheet width / frame width, so no code change is needed.

static func build(entity: String) -> SpriteFrames:
    var def: Dictionary = GameConfig.ANIMATIONS[entity]
    var fsize: Vector2i = def["frame_size"]
    var frames := SpriteFrames.new()
    if frames.has_animation("default"):
        frames.remove_animation("default")
    var anims: Dictionary = def["anims"]
    for anim_name in anims:
        var a: Dictionary = anims[anim_name]
        var sheet_size := Vector2i(fsize.x * int(a["frames"]), fsize.y)
        var sheet: Texture2D = Assets.texture(a["file"], sheet_size, def["placeholder_color"], fsize.x)
        var count := maxi(1, sheet.get_width() / fsize.x)
        var key := StringName(str(anim_name))
        frames.add_animation(key)
        frames.set_animation_speed(key, float(a["fps"]))
        frames.set_animation_loop(key, bool(a["loop"]))
        for i in count:
            var tex := AtlasTexture.new()
            tex.atlas = sheet
            tex.region = Rect2(i * fsize.x, 0, fsize.x, fsize.y)
            frames.add_frame(key, tex)
    return frames
