extends Node
## AUTOLOAD. Why: unlock state is global and queried by player + UI.
## Skills unlock automatically when their understanding reaches the requirement.

signal skill_unlocked(skill_id: String)

var _unlocked := {}

func _ready() -> void:
    UnderstandingManager.understanding_changed.connect(_on_understanding_changed)

func reset() -> void:
    _unlocked.clear()

func is_unlocked(skill_id: String) -> bool:
    return _unlocked.has(skill_id)

func get_skill(skill_id: String) -> Dictionary:
    return GameConfig.SKILLS.get(skill_id, {})

## Returns the real name once unlocked, otherwise "؟؟؟".
func get_display_name(skill_id: String) -> String:
    if is_unlocked(skill_id):
        return get_skill(skill_id).get("name_fa", skill_id)
    return "؟؟؟"

func _on_understanding_changed(_id: String, _old: float, _new: float) -> void:
    # Deferred so UI reacts to the understanding change first (message order).
    _check_unlocks.call_deferred()

func _check_unlocks() -> void:
    for skill_id in GameConfig.SKILLS:
        if _unlocked.has(skill_id):
            continue
        var s: Dictionary = GameConfig.SKILLS[skill_id]
        if UnderstandingManager.get_value(s["understanding"]) >= float(s["required"]):
            _unlocked[skill_id] = true
            skill_unlocked.emit(skill_id)
