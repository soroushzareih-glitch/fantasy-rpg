extends Area2D
class_name MagicBook
## Interactable book. Reading it sets an understanding value instantly.

@export var prompt_text := "برای مطالعه لمس کنید"
@export var understanding_id := "fire"
@export var understanding_value := 100.0

var _read := false

@onready var sprite: Sprite2D = $Sprite2D

func _ready() -> void:
    sprite.texture = Assets.texture(GameConfig.TEX_BOOK, Vector2i(32, 32), Color(0.5, 0.3, 0.1), 32)
    body_entered.connect(_on_body_entered)
    body_exited.connect(_on_body_exited)
    var tw := create_tween().set_loops()
    tw.tween_property(sprite, "position:y", -3.0, 0.9).set_trans(Tween.TRANS_SINE)
    tw.tween_property(sprite, "position:y", 0.0, 0.9).set_trans(Tween.TRANS_SINE)

func _on_body_entered(body: Node) -> void:
    if body is Player and not _read:
        GameManager.set_interactable(self)

func _on_body_exited(body: Node) -> void:
    if body is Player:
        GameManager.clear_interactable(self)

## Called by GameManager.interact() when the player taps the prompt.
func interact() -> void:
    if _read:
        return
    _read = true
    GameManager.clear_interactable(self)
    sprite.modulate = Color(0.6, 0.6, 0.6)
    UnderstandingManager.set_value(understanding_id, understanding_value)
