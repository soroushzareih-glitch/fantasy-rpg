extends CanvasLayer
class_name GameUI
## Mobile HUD built in code: HP/MP bars, understanding/skills panel,
## message line, joystick, Fire button, interact prompt. All text is Persian.

signal cast_requested(skill_id: String)

const FIRE_SKILL := "fire_magic"
const FONT_PATH := "res://assets/ui/fonts/main_font.ttf"  # optional Persian font

var _root: Control
var _hp_bar: ProgressBar
var _mp_bar: ProgressBar
var _understanding_label: Label
var _skills_label: Label
var _message_label: Label
var _joystick: VirtualJoystick
var _fire_button: Button
var _interact_button: Button
var _queue: Array = []
var _current_message := ""
var _pumping := false

func _ready() -> void:
    layer = 10
    _root = Control.new()
    _root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _root.theme = _make_theme()
    add_child(_root)
    _root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _build_bars()
    _build_info_panel()
    _build_message_label()
    _build_controls()
    GameManager.message_posted.connect(_enqueue_message)
    GameManager.interactable_changed.connect(_on_interactable_changed)
    UnderstandingManager.understanding_changed.connect(_on_understanding_changed)
    SkillManager.skill_unlocked.connect(_on_skill_unlocked)
    _refresh_understanding()
    _refresh_skills()

func bind_player(player: Player) -> void:
    player.hp_changed.connect(func(cur: int, mx: int): _set_bar(_hp_bar, "سلامت", cur, mx))
    player.mp_changed.connect(func(cur: float, mx: int): _set_bar(_mp_bar, "مانا", int(cur), mx))
    player.emit_stats()

# ---------------- Building ----------------
func _make_theme() -> Theme:
    var t := Theme.new()
    if ResourceLoader.exists(FONT_PATH):
        var f = load(FONT_PATH)
        if f is Font:
            t.default_font = f
    t.default_font_size = 26
    t.set_color("font_outline_color", "Label", Color.BLACK)
    t.set_constant("outline_size", "Label", 5)
    var panel := StyleBoxFlat.new()
    panel.bg_color = Color(0, 0, 0, 0.5)
    panel.set_corner_radius_all(10)
    panel.set_content_margin_all(10)
    t.set_stylebox("panel", "PanelContainer", panel)
    return t

func _place(c: Control, anchor: Vector2, l: float, t: float, r: float, b: float) -> void:
    c.anchor_left = anchor.x
    c.anchor_right = anchor.x
    c.anchor_top = anchor.y
    c.anchor_bottom = anchor.y
    c.offset_left = l
    c.offset_top = t
    c.offset_right = r
    c.offset_bottom = b

func _make_bar(fill: Color) -> ProgressBar:
    var bar := ProgressBar.new()
    bar.custom_minimum_size = Vector2(320, 36)
    bar.show_percentage = false
    var bg := StyleBoxFlat.new()
    bg.bg_color = Color(0, 0, 0, 0.55)
    bg.set_corner_radius_all(8)
    var fg := StyleBoxFlat.new()
    fg.bg_color = fill
    fg.set_corner_radius_all(8)
    bar.add_theme_stylebox_override("background", bg)
    bar.add_theme_stylebox_override("fill", fg)
    var lbl := Label.new()
    lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    bar.add_child(lbl)
    lbl.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    return bar

func _set_bar(bar: ProgressBar, title: String, cur: int, mx: int) -> void:
    bar.max_value = mx
    bar.value = cur
    (bar.get_child(0) as Label).text = Fa.digits("%s: %d / %d" % [title, cur, mx])

func _build_bars() -> void:
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 8)
    _hp_bar = _make_bar(Color(0.85, 0.2, 0.25))
    _mp_bar = _make_bar(Color(0.2, 0.45, 0.95))
    box.add_child(_hp_bar)
    box.add_child(_mp_bar)
    _root.add_child(box)
    _place(box, Vector2(0, 0), 20, 20, 340, 100)

func _build_info_panel() -> void:
    var panel := PanelContainer.new()
    var box := VBoxContainer.new()
    _understanding_label = Label.new()
    _skills_label = Label.new()
    box.add_child(_understanding_label)
    box.add_child(_skills_label)
    panel.add_child(box)
    _root.add_child(panel)
    _place(panel, Vector2(1, 0), -300, 20, -20, 100)
    panel.grow_horizontal = Control.GROW_DIRECTION_BEGIN

func _build_message_label() -> void:
    _message_label = Label.new()
    _message_label.visible = false
    _message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _message_label.add_theme_font_size_override("font_size", 32)
    _message_label.add_theme_color_override("font_color", Color(1, 0.95, 0.6))
    _root.add_child(_message_label)
    _place(_message_label, Vector2(0.5, 0), -420, 130, 420, 190)

func _make_button(text: String, min_size: Vector2, color: Color, radius: int) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = min_size
    b.focus_mode = Control.FOCUS_NONE
    b.add_theme_font_size_override("font_size", 34)
    var sb := StyleBoxFlat.new()
    sb.bg_color = color
    sb.set_corner_radius_all(radius)
    for state in ["normal", "hover", "pressed"]:
        b.add_theme_stylebox_override(state, sb)
    return b

func _build_controls() -> void:
    _joystick = VirtualJoystick.new()
    _joystick.custom_minimum_size = Vector2(240, 240)
    _joystick.vector_changed.connect(func(v: Vector2): GameManager.move_input = v)
    _root.add_child(_joystick)
    _place(_joystick, Vector2(0, 1), 40, -280, 280, -40)

    var skill := SkillManager.get_skill(FIRE_SKILL)
    _fire_button = _make_button(skill.get("button_text", "آتش"), Vector2(160, 160), Color(0.9, 0.35, 0.1, 0.9), 80)
    _fire_button.visible = SkillManager.is_unlocked(FIRE_SKILL)
    _root.add_child(_fire_button)
    _place(_fire_button, Vector2(1, 1), -220, -220, -60, -60)

    _interact_button = _make_button("برای مطالعه لمس کنید", Vector2(420, 72), Color(0.15, 0.4, 0.3, 0.92), 16)
    _interact_button.visible = false
    _root.add_child(_interact_button)
    _place(_interact_button, Vector2(0.5, 1), -210, -150, 210, -78)

# ---------------- Touch buttons ----------------
# Handled via raw touch events (not Button.pressed) so that a second finger
# can press Fire while the first finger holds the joystick.
func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch and event.pressed:
        if _fire_button.visible and _hit(_fire_button, event.position):
            cast_requested.emit(FIRE_SKILL)
            get_viewport().set_input_as_handled()
        elif _interact_button.visible and _hit(_interact_button, event.position):
            GameManager.interact()
            get_viewport().set_input_as_handled()

func _hit(c: Control, pos: Vector2) -> bool:
    return c.get_global_rect().has_point(pos)

# ---------------- Reactions ----------------
func _on_interactable_changed(target: Node) -> void:
    if target == null or not is_instance_valid(target):
        _interact_button.visible = false
        return
    _interact_button.text = str(target.get("prompt_text"))
    _interact_button.visible = true

func _on_understanding_changed(id: String, _old: float, new_value: float) -> void:
    _refresh_understanding()
    var n := UnderstandingManager.get_display_name(id)
    if new_value >= UnderstandingManager.MAX_VALUE:
        _enqueue_message(Fa.digits("درک شما از %s به %d٪ رسید." % [n, 100]))
    else:
        _enqueue_message(Fa.digits("درک شما از %s افزایش یافت: %d٪" % [n, int(new_value)]))

func _on_skill_unlocked(skill_id: String) -> void:
    _refresh_skills()
    _enqueue_message("مهارت جدید کشف شد: " + SkillManager.get_display_name(skill_id))
    _enqueue_message(SkillManager.get_skill(skill_id).get("unlock_message", ""))
    if skill_id == FIRE_SKILL:
        _fire_button.visible = true

func _refresh_understanding() -> void:
    var v := int(UnderstandingManager.get_value("fire"))
    _understanding_label.text = Fa.digits("درک %s: %d٪" % [UnderstandingManager.get_display_name("fire"), v])

func _refresh_skills() -> void:
    var names := PackedStringArray()
    for sid in GameConfig.SKILLS:
        names.append(SkillManager.get_display_name(sid))
    _skills_label.text = "مهارت‌ها: " + "، ".join(names)

# ---------------- Message queue ----------------
func _enqueue_message(text: String) -> void:
    if text == "" or text == _current_message or _queue.has(text):
        return
    _queue.append(text)
    if not _pumping:
        _pump_messages()

func _pump_messages() -> void:
    _pumping = true
    while not _queue.is_empty():
        _current_message = _queue.pop_front()
        _message_label.text = _current_message
        _message_label.visible = true
        await get_tree().create_timer(GameConfig.MESSAGE_DURATION).timeout
    _current_message = ""
    _message_label.visible = false
    _pumping = false
