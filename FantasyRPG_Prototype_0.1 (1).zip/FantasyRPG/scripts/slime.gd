extends CharacterBody2D
class_name Slime
## Simple chaser enemy with attack cooldown, hurt and death handling.

signal died(slime: Slime)

var hp: int = GameConfig.SLIME_MAX_HP
var _dead := false
var _attack_timer := 0.0
var _anim_locked := false
var _player: Player = null

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var indicator: Sprite2D = $TargetIndicator
@onready var body_shape: CollisionShape2D = $CollisionShape2D

func _ready() -> void:
    sprite.sprite_frames = AnimBuilder.build("slime")
    sprite.play("idle")
    sprite.animation_finished.connect(_on_animation_finished)
    indicator.texture = Assets.texture(GameConfig.TEX_TARGET_RING, Vector2i(48, 48), Color(1, 0.2, 0.2), 48)
    indicator.visible = false

func is_alive() -> bool:
    return not _dead

func set_targeted(value: bool) -> void:
    indicator.visible = value and not _dead

func _physics_process(delta: float) -> void:
    if _dead:
        return
    _attack_timer -= delta
    if not is_instance_valid(_player):
        _player = get_tree().get_first_node_in_group("player") as Player
    if _player == null or not _player.is_alive():
        velocity = Vector2.ZERO
        _play_loop("idle")
        return
    var to_player := _player.global_position - global_position
    var dist := to_player.length()
    if dist > GameConfig.SLIME_AGGRO_RADIUS:
        velocity = Vector2.ZERO
        _play_loop("idle")
    elif dist > GameConfig.SLIME_ATTACK_RANGE:
        velocity = to_player.normalized() * GameConfig.SLIME_SPEED
        _play_loop("move")
    else:
        velocity = Vector2.ZERO
        if _attack_timer <= 0.0:
            _attack()
        else:
            _play_loop("idle")
    if absf(to_player.x) > 1.0:
        sprite.flip_h = to_player.x < 0.0
    move_and_slide()

func _attack() -> void:
    _attack_timer = GameConfig.SLIME_ATTACK_COOLDOWN
    _play_locked("attack")
    _player.take_damage(GameConfig.SLIME_DAMAGE)

func take_damage(amount: int) -> void:
    if _dead:
        return
    hp = maxi(0, hp - amount)
    queue_redraw()
    if hp <= 0:
        _die()
    else:
        _play_locked("hurt")

func _die() -> void:
    _dead = true
    velocity = Vector2.ZERO
    indicator.visible = false
    body_shape.set_deferred("disabled", true)
    _anim_locked = true
    sprite.play("death")
    queue_redraw()
    died.emit(self)
    get_tree().create_timer(GameConfig.SLIME_REMOVE_DELAY).timeout.connect(queue_free)

func _play_loop(anim: String) -> void:
    if not _anim_locked and sprite.animation != anim:
        sprite.play(anim)

func _play_locked(anim: String) -> void:
    _anim_locked = true
    sprite.play(anim)
    get_tree().create_timer(0.6).timeout.connect(_unlock_anim)  # safety if art loops

func _unlock_anim() -> void:
    if not _dead:
        _anim_locked = false

func _on_animation_finished() -> void:
    if not _dead and (sprite.animation == "attack" or sprite.animation == "hurt"):
        _anim_locked = false

## Small HP bar above the slime.
func _draw() -> void:
    if _dead:
        return
    var w := 24.0
    draw_rect(Rect2(-w / 2.0, -20.0, w, 3.0), Color(0, 0, 0, 0.7))
    var ratio := float(hp) / float(GameConfig.SLIME_MAX_HP)
    draw_rect(Rect2(-w / 2.0, -20.0, w * ratio, 3.0), Color(0.9, 0.2, 0.2))
