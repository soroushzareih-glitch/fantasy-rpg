extends Node
## AUTOLOAD. Why: understanding values are global progress data that
## UI, books and the skill system all read. Values go 0 -> 100.

signal understanding_changed(id: String, old_value: float, new_value: float)

const MAX_VALUE := 100.0
var _values := {}

func _ready() -> void:
    reset()

func reset() -> void:
    _values.clear()
    for id in GameConfig.UNDERSTANDINGS:
        _values[id] = 0.0

func get_value(id: String) -> float:
    return _values.get(id, 0.0)

func get_display_name(id: String) -> String:
    return GameConfig.UNDERSTANDINGS.get(id, {}).get("name_fa", id)

func add(id: String, amount: float) -> void:
    set_value(id, get_value(id) + amount)

func set_value(id: String, value: float) -> void:
    if not GameConfig.UNDERSTANDINGS.has(id):
        push_warning("Unknown understanding id: " + id)
        return
    var old := get_value(id)
    var new_value := clampf(value, 0.0, MAX_VALUE)
    if is_equal_approx(old, new_value):
        return
    _values[id] = new_value
    understanding_changed.emit(id, old, new_value)
