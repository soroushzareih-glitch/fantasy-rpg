extends RefCounted
class_name Fa
## Persian text helpers.

const _DIGITS := "۰۱۲۳۴۵۶۷۸۹"

## Converts Latin digits in a string to Persian digits.
static func digits(text: String) -> String:
    var out := ""
    for ch in text:
        if ch >= "0" and ch <= "9":
            out += _DIGITS[ch.to_int()]
        else:
            out += ch
    return out
