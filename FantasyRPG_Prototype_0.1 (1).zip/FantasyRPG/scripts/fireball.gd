extends Area2D
class_name Fireball
## Homing projectile. Safe if the target dies: it keeps flying straight and
## despawns on hit / wall / lifetime end.

var _target: Node2D = null
var _damage := 0
var _speed := 200.0
var _dir := Vector2.RIGHT
var _hit := false

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D

func _ready() -> void:
    sprite.sprite_frames = AnimBuilder.build("fireball")
    sprite.play("fly")
    sprite.animation_finished.connect(_on_animation_finished)
    body_entered.connect(_on_body_entered)
    get_tree().create_timer(GameConfig.FIREBALL_LIFETIME).timeout.connect(_on_lifetime_end)

func setup(target: Node2D, damage: int, speed: float) -> void:
    _target = target
    _damage = damage
    _speed = speed
    _aim()

func _aim() -> void:
    if is_instance_valid(_target) and _target.is_alive():
        _dir = (_target.global_position - global_position).normalized()
        rotation = _dir.angle()

func _physics_process(delta: float) -> void:
    if _hit:
        return
    _aim()
    global_position += _dir * _speed * delta

func _on_body_entered(body: Node) -> void:
    if _hit:
        return
    if body.is_in_group("enemies"):
        if body.has_method("take_damage") and body.is_alive():
            body.take_damage(_damage)
            _impact()
    else:
        _impact()  # wall

func _impact() -> void:
    _hit = true
    set_deferred("monitoring", false)
    sprite.rotation = 0.0
    sprite.play("impact")
    get_tree().create_timer(0.8).timeout.connect(_free_safe)  # safety

func _on_animation_finished() -> void:
    if sprite.animation == "impact":
        _free_safe()

func _on_lifetime_end() -> void:
    if not _hit:
        _free_safe()

func _free_safe() -> void:
    if is_inside_tree():
        queue_free()
