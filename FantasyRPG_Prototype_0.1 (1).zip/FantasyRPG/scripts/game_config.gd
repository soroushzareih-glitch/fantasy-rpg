extends RefCounted
class_name GameConfig
## Single source of truth for every tunable value in the prototype.
## Change numbers here, not inside gameplay scripts.

# --- Collision layers (names also defined in project.godot) ---
const LAYER_WORLD := 1
const LAYER_PLAYER := 2
const LAYER_ENEMY := 4
const LAYER_PROJECTILE := 8
const LAYER_INTERACTABLE := 16

# --- Player ---
const PLAYER_MAX_HP := 20
const PLAYER_MAX_MP := 10
const PLAYER_MP_REGEN_PER_SEC := 1.0
const PLAYER_SPEED := 90.0
const PLAYER_BASE_ATTRIBUTES := {"str": 5, "int": 5, "vit": 5, "agi": 5}
const ATTRIBUTE_NAMES_FA := {"str": "قدرت", "int": "هوش", "vit": "استقامت", "agi": "چابکی"}
const TARGET_LOCK_RADIUS := 150.0
const CAST_COOLDOWN := 0.35

# --- Slime ---
const SLIME_MAX_HP := 35
const SLIME_DAMAGE := 1
const SLIME_SPEED := 35.0
const SLIME_AGGRO_RADIUS := 200.0
const SLIME_ATTACK_RANGE := 26.0
const SLIME_ATTACK_COOLDOWN := 1.0
const SLIME_REMOVE_DELAY := 1.0

# --- Fireball ---
const FIREBALL_SPEED := 220.0
const FIREBALL_LIFETIME := 3.0

# --- World / UI ---
const MAP_SIZE := Vector2(720, 480)
const MESSAGE_DURATION := 1.7

# --- Understanding (add Water, Wind, Sword ... here later) ---
const UNDERSTANDINGS := {
    "fire": {"name_fa": "آتش"},
}

# --- Skills (add new skills here later) ---
const SKILLS := {
    "fire_magic": {
        "name_fa": "جادوی آتش",
        "understanding": "fire",
        "required": 100.0,
        "mana_cost": 3,
        "damage": 10,
        "button_text": "🔥 آتش",
        "unlock_message": "🔥 جادوی آتش باز شد!",
    },
}

# --- Animations: sprite sheets are horizontal strips, one file per animation ---
# frame_size = size of ONE frame. "frames" is only used for placeholders;
# with real art the frame count is read from the sheet width.
const ANIMATIONS := {
    "player": {
        "frame_size": Vector2i(32, 32),
        "placeholder_color": Color(0.25, 0.4, 0.9),
        "anims": {
            "idle": {"file": "res://assets/player/player_idle.png", "frames": 4, "fps": 5.0, "loop": true},
            "walk": {"file": "res://assets/player/player_walk.png", "frames": 6, "fps": 10.0, "loop": true},
            "attack": {"file": "res://assets/player/player_attack.png", "frames": 4, "fps": 12.0, "loop": false},
        },
    },
    "slime": {
        "frame_size": Vector2i(32, 32),
        "placeholder_color": Color(0.3, 0.8, 0.35),
        "anims": {
            "idle": {"file": "res://assets/mobs/slime/slime_idle.png", "frames": 4, "fps": 5.0, "loop": true},
            "move": {"file": "res://assets/mobs/slime/slime_move.png", "frames": 4, "fps": 7.0, "loop": true},
            "attack": {"file": "res://assets/mobs/slime/slime_attack.png", "frames": 4, "fps": 10.0, "loop": false},
            "hurt": {"file": "res://assets/mobs/slime/slime_hurt.png", "frames": 2, "fps": 10.0, "loop": false},
            "death": {"file": "res://assets/mobs/slime/slime_death.png", "frames": 5, "fps": 8.0, "loop": false},
        },
    },
    "fireball": {
        "frame_size": Vector2i(32, 32),
        "placeholder_color": Color(1.0, 0.5, 0.1),
        "anims": {
            "fly": {"file": "res://assets/magic/fireball.png", "frames": 4, "fps": 12.0, "loop": true},
            "impact": {"file": "res://assets/magic/fireball_impact.png", "frames": 5, "fps": 14.0, "loop": false},
        },
    },
}

# --- Static images ---
const TEX_GRASS := "res://assets/environment/grass.png"
const TEX_BOOK := "res://assets/environment/book.png"
const TEX_TARGET_RING := "res://assets/ui/target_ring.png"
